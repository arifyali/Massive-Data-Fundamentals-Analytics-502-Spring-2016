HW 1 File breakdown
=====================

Part 1
-------
All materials relevant to part 1 of HW 1, are located in the Part 1 directory,
It this, I have included the Java file, the jar file, and 3 PDFs.
In order to create the jar file, I bypassed the command lines and created them via eclipse.
I would like to credit Nathan for showing me how.

The 3 PDFs are:
1. Command lines for part 1
2. Hadoop Output
3. The top 10 words

I would like to credit Jordan for showing me how to limit the output using: | sort -k2n | tail | tac

Part 2
--------
All materials relevant to part 2 of HW 1, are located in the Part 2 directory
It this, I have included the 2 python scripts and 3 PDFs.

The mapper.py and reducer.py were found in http://www.michael-noll.com/tutorials/writing-an-hadoop-mapreduce-program-in-python/

The 3 PDFs are:
1. Command lines for part 2
2. Hadoop Output
3. The top 10 words

I would like to credit Jordan again for showing me how to limit the output using: | sort -k2n | tail | tac

Part 2
--------
All materials relevant to part 3 of HW 1, are located in the Part 1 directory
It this, I have included the 1 python scripts and 9 PDFs.

I would like to credit Professor. Simson Garfinkel for wordcount_top10.py 

The 9 PDFs are:
1. Command lines for part 3 (inline)
2. Hadoop Output
3. The top 10 words

1. Command lines for part 3 (local)
2. Hadoop Output
3. The top 10 words

1. Command lines for part 3 (hadoop)
2. Hadoop Output
3. The top 10 words

I also like to credit Nathan (response on the discussion board)